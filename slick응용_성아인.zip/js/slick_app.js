$(function(){
    $('#item').slick({
      dots:true,  
      autoplay: true,
      infinite: true,
      autoplaySpeed: 1500,
      slidesToShow: 4,
      slidesToScroll: 1, 
      responsive: [
        {
              breakpoint: 1200,
              settings: {
                slidesToShow: 4,
                slidesToScroll: 1
              }
      },
        {
              breakpoint: 1000,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1
              }
      },
        {
              breakpoint: 760,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1
              }
      },
      {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
      }
    ]
    });
    $("#btn li a").on("click",function(e){
      const n=$(this).parent().index();
         if (n==0) {
          $("#item").slick("slickUnfilter");
       }else if(n==1){
          $("#item").slick("slickUnfilter");
          $("#item").slick("slickFilter", $("#item li").filter(".cf"));
        }else if(n==2){
          $("#item").slick("slickUnfilter");
          $("#item").slick("slickFilter", $("#item li").filter(".dcf"));
        }else{
          $("#item").slick("slickUnfilter");
          $("#item").slick("slickFilter", $("#item li").filter(".jc"));
        }
        e.preventDefault();
    });
    
});