class themeController{
    constructor(){
        this.body = document.querySelector("body");
        this.mode = "day";
        this.title = document.querySelector("h1");
        this.text = document.querySelector(".itd");
    }
    setBodyColor(color){
        this.body.style.color = color;
    }
    setBackgroundColor(color){
        this.body.style.backgroundColor = color;
    }
    setTitleColor(color){
        this.title.style.color = color;
    }
    setTextColor(color){
        this.text.style.color = color;
    }

    toggle(btn){
        if(this.mode === "day"){
            this.setBackgroundColor("#4a4a4a");
            this.setBodyColor("white");
            this.setTitleColor("white");
            this.setTextColor("white");

            this.mode = "night";
            btn.value = "night";
        }
        else{
            this.setBackgroundColor("white");
            this.setBodyColor("black");
            this.setTitleColor("black");
            this.setTextColor("#4a4a4a");

            this.mode = "day";
            btn.value = "day";
        }
    }
}
const theme = new themeController();
function day_night(btn,e){
e.preventDefault();
theme.toggle(btn);
}